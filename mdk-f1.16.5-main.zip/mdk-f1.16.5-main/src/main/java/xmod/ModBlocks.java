package xmod;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraftforge.fml.RegistryObject;

import java.util.function.Supplier;

public class ModBlocks {
    public static final RegistryObject<Block> MACHINE_FRAME = registerBlock("machine_frame", 
            () -> new Block(AbstractBlock.Properties.create(Material.IRON).hardnessAndResistance(5.0f).harvestLevel(2)));

    private static <T extends Block> RegistryObject<T> registerBlock(String name, Supplier<T> block) {
        RegistryObject<T> toReturn = IndustrialMod.BLOCKS.register(name, block);
        registerBlockItem(name, toReturn);
        return toReturn;
    }

    private static <T extends Block> void registerBlockItem(String name, RegistryObject<T> block) {
        IndustrialMod.ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties().group(ItemGroup.MISC)));
    }

    public static void register() {}
}
